Rogue Clone IV version 2.1
==========================

Welcome to Rogue Clone IV!

In previous versions this program was called DOS Rogue Clone. The name was
changed when we adapted the game to run as a Windows console application. Expect
ports to other systems in the future.

The files rogue.html and guide.html contain all the information you need to
play. Help is also available within the game by using the '?' and '/' commands.

To get the latest version of Rogue Clone IV, visit
http://rogueclone.sourceforge.net on the web. At our web site you will find news
about current and upcoming releases, information about the Rogue Clone IV
mailing lists, forms for submitting patches and bug reports, nightly development
snapshots, and up-to-the-minute source code from our CVS repository.

Rogue Clone IV may be freely distributed. See the file LICENSE.TXT for details.
